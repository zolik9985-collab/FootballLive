# Football Live 1.8 — Live Statistics

Android project. Build with Java 17 and Gradle 8.9 using `gradle assembleDebug`.

GitHub Actions publishes one artifact named `FootballLive-APK` containing a single file at its root: `FootballLive.apk` (no nested project folders).

API key is entered and stored locally on the device. Do not commit API keys.

Statistics refreshes every 60 seconds while the match details window is open. Notifications are triggered when supported numeric stats increase. Availability depends on SportAPI coverage; unavailable values remain dashes.
