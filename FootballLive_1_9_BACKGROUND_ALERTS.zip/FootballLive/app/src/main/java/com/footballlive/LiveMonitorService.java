package com.footballlive;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.media.Ringtone;
import android.media.RingtoneManager;
import java.net.*;
import java.io.*;
import java.util.*;
import org.json.*;

public class LiveMonitorService extends Service {
 private static final String CHANNEL="live_monitor";
 private Handler handler=new Handler(Looper.getMainLooper());
 private Runnable loop;
 private SharedPreferences prefs;
 private final String[] keys={"goal","yellow_card","red_card","substitution","kickoff","fulltime","corner","foul","shot_on_target","shot_off_target","offside"};
 private final String[] labels={"Гол","Жёлтая карточка","Красная карточка","Замена","Начало матча","Конец матча","Угловой","Фол","Удар в створ","Удар мимо ворот","Офсайд"};
 @Override public void onCreate(){super.onCreate();prefs=getSharedPreferences("sportapi_live",0);createChannel();}
 private void createChannel(){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26){nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Football Live — фоновое наблюдение",NotificationManager.IMPORTANCE_LOW));nm.createNotificationChannel(new NotificationChannel("live_events","Football Live — события",NotificationManager.IMPORTANCE_HIGH));}}
 @Override public int onStartCommand(Intent i,int flags,int startId){
  startForeground(901,ongoing("Наблюдение за выбранными матчами"));
  if(loop==null){loop=new Runnable(){public void run(){poll();handler.postDelayed(this,60000);}};handler.post(loop);}
  return START_STICKY;
 }
 private Notification ongoing(String msg){Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);return b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Football Live").setContentText(msg).setOngoing(true).build();}
 private void poll(){Set<String> ids=prefs.getStringSet("tracked",new HashSet<>());if(ids.isEmpty())return;String key=prefs.getString("api_key","").trim();if(key.isEmpty())return;
  new Thread(()->{for(String id:ids){try{JSONObject j=get("fixtures/"+id+"/events",key);JSONArray arr=j.optJSONArray("data");if(arr==null)continue;for(int n=0;n<arr.length();n++){JSONObject e=arr.optJSONObject(n);if(e!=null)handleEvent(e,id);}}catch(Exception ignored){}}}).start();
 }
 private JSONObject get(String path,String key)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL("https://sportapi.ai/api/"+path).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestProperty("X-Api-Key",key);c.setRequestProperty("Accept","application/json");int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream o=new ByteArrayOutputStream();if(in!=null){byte[]b=new byte[4096];int n;while((n=in.read(b))>0)o.write(b,0,n);}c.disconnect();if(code<200||code>=300)throw new IOException("HTTP "+code);return new JSONObject(o.toString("UTF-8"));}
 private void handleEvent(JSONObject e,String matchId){String t=e.optString("event_type","").toLowerCase(Locale.ROOT);int ix=-1;
  if(t.contains("goal"))ix=0;else if(t.contains("yellow"))ix=1;else if(t.contains("red"))ix=2;else if(t.contains("sub"))ix=3;else if(t.contains("corner"))ix=6;else if(t.contains("foul"))ix=7;else if(t.contains("offside"))ix=10;else if(t.contains("shot")&&(t.contains("target")||t.contains("on goal")))ix=8;else if(t.contains("shot"))ix=9;
  if(ix<0||!prefs.getBoolean("enabled_"+keys[ix],false))return;
  String eid=e.optString("id",t+"_"+e.optString("minute")+"_"+e.optString("player_name"));String seen="bg_seen_"+matchId+"_"+eid;
  synchronized(this){if(prefs.getBoolean(seen,false))return;prefs.edit().putBoolean(seen,true).apply();}
  String tone=prefs.getString("tone_"+keys[ix],"");Uri u=tone.isEmpty()?RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION):Uri.parse(tone);
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"live_events"):new Notification.Builder(this);
  Notification n=b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Football Live · "+labels[ix]).setContentText("Матч #"+matchId+" · "+e.optString("minute","")+"′ · "+e.optString("player_name","")).setAutoCancel(true).build();
  ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify((matchId+eid).hashCode(),n);
  try{Ringtone r=RingtoneManager.getRingtone(this,u);if(r!=null)r.play();}catch(Exception ignored){}
 }
 @Override public void onDestroy(){if(loop!=null)handler.removeCallbacks(loop);super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
