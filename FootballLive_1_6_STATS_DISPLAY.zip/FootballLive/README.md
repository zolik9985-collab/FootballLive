# Football Live — SportAPI edition

Android project using SportAPI (`https://sportapi.ai/api`).

## Setup
1. Create a free account at https://sportapi.ai/ and create an API key (starts with `sk_live_`).
2. Install the APK, paste the key in the app and tap **СОХРАНИТЬ API-КЛЮЧ**.
3. Tap **ОБНОВИТЬ LIVE-МАТЧИ**. Today's fixtures are refreshed every 60 seconds.
4. Open a match to request its statistics and events. The app displays missing values as a dash, never as fabricated zeroes.

## Data coverage caveats
SportAPI's published `/fixtures/{id}/stats` example includes shots, shots on target/off target, fouls, passes, pass accuracy, tackles, saves and yellow cards. Its published stats schema does not list corners, so the app cannot promise corner statistics from this provider. Match-event coverage can vary by competition. See https://sportapi.ai/docs.

The free plan requires an API key and is currently documented as 2,000 requests/day and 14,000/month through 30 November 2026; from 1 December 2026 it changes to 1,000/day and 7,000/month. Polling is therefore limited to once per minute, and detail requests happen only when a match is opened.

## Build on GitHub
Upload the generated `FootballLive_1_0.zip` file to the root of your GitHub repository. The workflow in `.github/workflows/build-apk.yml` extracts it and builds a debug APK. Download the APK from the successful GitHub Actions run under **Artifacts**.
