# Football Live 1.1

Separate Android app for live football scores, match details and user-selectable event alerts.

## Build

The repository root must contain `settings.gradle`, `build.gradle`, `gradle.properties`, `app/` and `.github/`.
GitHub Actions workflow: **Build Football Live APK**. Run it manually from Actions or push a source change. Download the `FootballLive-APK` artifact after a successful build.

## Data source and limits

Live fixtures and match detail are requested from SportScore's public widget API. No API key is required for its attribution tier; keep the visible `Powered by SportScore` link in the app. The API documents live/recent match scores, status, lineups and timeline. It does not promise every detailed live statistic for every competition. The app displays only values actually returned by the provider and shows a missing-data message instead of inventing zeroes.

The app refreshes the match list about once per minute while open. Event alerts depend on the provider including the relevant event in the match timeline. A checkbox can enable or disable each event type and a separate Android notification sound can be selected. This first version does not guarantee background monitoring after Android closes the app, and it cannot alert on statistic counters that the provider does not publish as events or statistics.

API documentation: https://sportscore.com/developers/
