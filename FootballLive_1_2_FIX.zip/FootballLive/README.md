# Football Live 1.2 — UI and match parsing fixes

Android app for live football scores using the public SportScore widget API.

## Changes in 1.2
- Better parsing of team names, competition names, score and match slug from alternate JSON field shapes.
- League filter matching accepts common naming variants (including UEFA prefixes).
- Match detail no longer blocks the user with a missing-ID popup; it attempts the documented match-slug route.
- Sound settings redesigned as readable dark rows with event names, event icons, a visible enable checkbox and a per-event sound picker.
- Labels include goals, corners, yellow/red cards, fouls, shots on target, offsides, throw-ins, kick-off and full-time.

## Data limitations
SportScore documents live/recent match listing and match detail endpoints. The exact availability of detailed live statistics and event categories can vary by match/competition. The app must show unavailable values as unavailable, not fabricate zeroes. The API documentation currently describes the match endpoint by `slug`; the tracker endpoint uses a numeric `id`.

## Build
Open this folder in Android Studio or use the repository GitHub Actions workflow to build the APK.

Data attribution: https://sportscore.com/
